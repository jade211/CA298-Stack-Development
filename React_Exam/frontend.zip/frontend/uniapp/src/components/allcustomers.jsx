import { useState, useEffect } from "react";
import { Link } from 'react-router-dom';
import React from 'react';
import {Card, Button } from 'react-bootstrap';

function AllCustomers(){
  const [allcustomers, setAllCustomers] = useState([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    fetch(`http://127.0.0.1:8000/api/customer/`)
      .then(response => response.json())
      .then(data => {
        setAllCustomers(data);
        setIsLoaded(true);
      })
      .catch(error => console.log(error));
  });

  const displayFacts = () => {
    return allcustomers.map(allcustomers =>
      <Card key={allcustomers.id} className="cardstyle" style={{marginBottom: '1rem', backgroundColor: 'rgba(255, 255, 255, 0.5)'}}>
          <Card.Body>
            <Card.Text>
            <strong>Customer Name: </strong>{allcustomers.name}
            <Button variant="dark" as={Link} to={`/allcustomers/${allcustomers.name}`}>View Customer Information</Button>
            </Card.Text>
          </Card.Body>
      </Card>
    )
  };

  if(isLoaded) {
    return (
      <div className="customerlist">
        <h2>All Customers</h2>
        {displayFacts()}
      </div>
    )
  }
  else {
    return (
      <p>Loading Customer Information...</p>
    )
  }
}

export default AllCustomers;
