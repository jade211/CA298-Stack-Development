import { useState, useEffect } from "react";
import { Link } from 'react-router-dom';
import React from 'react';
import {Card, Button } from 'react-bootstrap';

function ProductsCategory(){
  const [productscategory, setProductsCategory] = useState([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    fetch(`http://127.0.0.1:8000/api/category/`)
      .then(response => response.json())
      .then(data => {
        setProductsCategory(data);
        setIsLoaded(true);
      })
      .catch(error => console.log(error));
  });

  const displayFacts = () => {
    return productscategory.map(category =>
      <Card key={category.id} className="cardstyle" style={{marginBottom: '1rem', backgroundColor: 'rgba(255, 255, 255, 0.5)'}}>
          <Card.Body>
            <Card.Title><strong>Category Title: </strong>{category.display_name}</Card.Title>
            <Card.Text>
              <strong>Category Short Code: </strong>{category.shortcode}
            <br></br>
            <Button variant="dark" as={Link} to={`/category/${category.shortcode}`}>View Degree Information</Button>
            </Card.Text>
          </Card.Body>
      </Card>
    )
  };

  if(isLoaded) {
    return (
      <div className="categorylist">
        <h2>Categories Available</h2>
        {displayFacts()}
      </div>
    )
  }
  else {
    return (
      <p>Loading Category Information...</p>
    )
  }
}

export default ProductsCategory;
