import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { Card } from 'react-bootstrap';

function OrderStatus() {
  const {status} = useParams();
  const [orderstatus, setorderStatus] = useState([]);
  const [isLoaded, setIsLoaded] = useState(false);



  useEffect(() => {
    fetch(`http://127.0.0.1:8000/api/order/?status=${status}`)
    .then((response) => response.json())
      .then(data => {
        setorderStatus(data);
        setIsLoaded(true);
      })
      .catch(error => console.log(error));
  }, [status]);

  const displayFacts = () => {
    return (
      <div>    
          {orderstatus.map(orderstatus => (
            <div key={orderstatus.id}>
              <strong>Customer: </strong>{orderstatus.customer}<br></br>
              <strong>Status: </strong> {orderstatus.status}<br></br>
              <br></br>
            </div>
          ))}
      </div>
    );
  };

  if (isLoaded) {
    return (
      <div style={{marginRight: '80px', marginLeft: '80px'}}>
      <Card key={status} className="cardstyle" style={{ paddingLeft: '20px', paddingRight: '20px', marginBottom: '1rem', backgroundColor: 'rgba(255, 255, 255, 0.5)' }}>
        <h2>Information on {status}</h2>
        <Card.Body>
          {displayFacts()}
        </Card.Body>
      </Card>
      </div>
    )
  } 
  else {
    return <p>Loading Order Information...</p>;
  }
}

export default OrderStatus;
