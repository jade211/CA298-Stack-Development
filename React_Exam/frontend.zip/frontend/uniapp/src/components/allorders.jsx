import { useState, useEffect } from "react";
import { Link } from 'react-router-dom';
import React from 'react';
import {Card, Button } from 'react-bootstrap';

function AllOrders(){
  const [orders, setOrders] = useState([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    fetch(`http://127.0.0.1:8000/api/order/`)
      .then(response => response.json())
      .then(data => {
        setOrders(data);
        setIsLoaded(true);
      })
      .catch(error => console.log(error));
  });

  const displayFacts = () => {
    return orders.map(orders =>
      <Card key={orders.id} className="cardstyle" style={{marginBottom: '1rem', backgroundColor: 'rgba(255, 255, 255, 0.5)'}}>
          <Card.Body>
            <Card.Title><strong>Customer Name: </strong>{orders.customer}</Card.Title>
            <Card.Text>
              <strong>Order: </strong>{orders.status}
            <br></br>
            <Button variant="dark" as={Link} to={`/orders/${orders.status}`}>View All Orders with this Status</Button>
            </Card.Text>
          </Card.Body>
      </Card>
    )
  };

  if(isLoaded) {
    return (
      <div className="categorylist">
        <h2>Categories Available</h2>
        {displayFacts()}
      </div>
    )
  }
  else {
    return (
      <p>Loading Category Information...</p>
    )
  }
}

export default AllOrders;
