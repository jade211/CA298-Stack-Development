
function HeadingComponent(){
	return (
		<div>
			<h1>Category Information!</h1>
				<div className="section-title">
				<a href="/category"><h2>All Categories</h2></a>
					<p> This page displays all of the categories of clothes available.</p>
				</div>
			
			<br></br>

			<h1>Customer Information!</h1>
				<div className="section-title">
				<a href="/allcustomers"><h2>All Customers</h2></a>
					<p> This page displays all of the customers.</p>
				</div>
			
			<br></br>
		
			<h1>Order Information!</h1>
				<div className="section-title">
				<a href="/allorders"><h2>All Orders</h2></a>
					<p> This page displays all of the current orders..</p>
				</div>
			
			<br></br>



		</div> 
	);
}

export default HeadingComponent;