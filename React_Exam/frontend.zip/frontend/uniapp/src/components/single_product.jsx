import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { Card } from 'react-bootstrap';

function SingleProductCategory() {
  const {shortcode} = useParams();
  const [product, setProduct] = useState([]);
  const [isLoaded, setIsLoaded] = useState(false);



  useEffect(() => {
    fetch(`http://127.0.0.1:8000/api/product/?category=${shortcode}`)
    .then((response) => response.json())
      .then(data => {
        setProduct(data);
        setIsLoaded(true);
      })
      .catch(error => console.log(error));
  }, [shortcode]);

  const displayFacts = () => {
    return (
      <div>    
          {product.map(product => (
            <div key={product.id}>
              <strong>Product: </strong>{product.name}<br></br>
              <strong>Price: </strong> {product.price}<br></br>
              <strong>Category: </strong> {product.category}<br></br>
              <strong>Category: </strong> {product.url}<br></br>
              <br></br>
            </div>
          ))}
      </div>
    );
  };

  if (isLoaded) {
    return (
      <div style={{marginRight: '80px', marginLeft: '80px'}}>
      <Card key={shortcode} className="cardstyle" style={{ paddingLeft: '20px', paddingRight: '20px', marginBottom: '1rem', backgroundColor: 'rgba(255, 255, 255, 0.5)' }}>
        <h2>Information on {shortcode}</h2>
        <Card.Body>
          {displayFacts()}
        </Card.Body>
      </Card>
      </div>
    )
  } 
  else {
    return <p>Loading Single Product Information...</p>;
  }
}

export default SingleProductCategory;
