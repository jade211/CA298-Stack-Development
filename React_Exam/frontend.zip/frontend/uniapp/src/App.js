import './App.css';
import "./styles.css";
import HeadingComponent from './components/heading';
import ProductsCategory from './components/allcategories';

import SingleProductCategory from './components/single_product';
import AllCustomers from './components/allcustomers';
import AllOrders from './components/allorders';

import OrderStatus from './components/orderstatus';


import { BrowserRouter, Routes, Route} from 'react-router-dom';
import React from 'react';
import { Nav, Navbar, NavDropdown } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
          <Navbar bg="light" expand="lg" className="Navbar-nav">
            <Navbar.Brand href="/" className="site-title">University Homepage</Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
              <Nav className="mr-auto">
              <Nav.Link href="/category">Categories Available</Nav.Link>
              <Nav.Link href="/allcustomers">Current Customers</Nav.Link>
              
              <NavDropdown title="Dropdown" id="basic-nav-dropdown">
              <NavDropdown.Item href="/category">See categories</NavDropdown.Item>
              <NavDropdown.Item href="/allcustomers">See customers</NavDropdown.Item>

            </NavDropdown>
          </Nav>
        </Navbar.Collapse>
      </Navbar>

      <Routes>
          <Route exact path="/" element={<HeadingComponent />} />
          <Route exact path="/category" element={<ProductsCategory />} />
          <Route exact path="/allcustomers" element={<AllCustomers />} />
          <Route exact path="/allorders" element={<AllOrders />} />



          
          <Route exact path="/category/:shortcode" element={<SingleProductCategory />} />
          <Route exact path="/allorders/:status" element={<OrderStatus />} />

        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
