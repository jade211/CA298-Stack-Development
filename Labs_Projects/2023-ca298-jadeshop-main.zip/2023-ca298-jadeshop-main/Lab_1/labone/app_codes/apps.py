from django.apps import AppConfig


class AppCodesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_codes'
