from django import forms
from .models import *
from datetime import datetime

class NewPizza(forms.ModelForm):
    class Meta:
        model = CreatePizza
        fields = ['size', 'crust', 'sauce', 'cheese', 'pepperoni', 'chicken', 'ham', 'pineapple', 'mushrooms', 'peppers', 'onions', 'olives', 'extra_cheese', 'bacon', 'sundried_tomatoes', 'sweetcorn', 'jalapeno_peppers', 'sausage', 'pickles']


class NewCustomer(forms.ModelForm):
    class Meta:
        model = Customer
        fields = ['name', 'address', 'card_number', 'card_expiry_month', 'card_expiry_year', 'card_cvv', 'pizza']

        widgets = {'pizza':forms.HiddenInput(),}
    
    def clean(self):
        data = self.cleaned_data
        name = data['name']
        address = data['address']
        card_number= data['card_number']
        card_expiry_month = data['card_expiry_month']
        card_expiry_year = data['card_expiry_year']
        card_cvv = data['card_cvv']
        pizza = data['pizza']


        # Card Number Validation (Number that is 16 OR 14 numbers long)
        if not card_number.isnumeric():
            raise forms.ValidationError("Invalid Card Number Entered - Must be Numerical Data Only")

        if len(card_number) != 16 and len(card_number) != 14:
            raise forms.ValidationError("Invalid Card Number Entered")
        

        # Card Expiration Validation
        if card_expiry_month < 1 or card_expiry_month > 12:
            raise forms.ValidationError("Invalid Month Entered")

        elif card_expiry_year < datetime.now().year or (card_expiry_year == datetime.now().year and card_expiry_month < datetime.now().month):
            raise forms.ValidationError("Card Invalid - Your Card Has Expired")


        # CVV Validation (Either 3 OR 4 digits long)
        if card_cvv < 100:
            raise forms.ValidationError("Invalid CVV Given")
        elif card_cvv > 9999:
            raise forms.ValidationError("Invalid CVV Given")

        return data
