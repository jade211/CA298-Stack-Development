from django.urls import path
from .views import *


urlpatterns = [
    path('', createPizza, name="index"),
    path('index', createPizza, name="index"),
    path('contact', contact, name="contact"),
    path('pizza', createPizza, name='create_pizza'),
    path('createCustomer/<int:pizzaId>', createCustomer, name='createCustomer'),
    path('createCustomer', createCustomer, name='createCustomer'),
    path('customer_pizza/<int:customerId>', customer_pizza, name='customer_pizza'),
]