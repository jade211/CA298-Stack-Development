import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { Link } from "react-router-dom";

function SingleCohort() {
    const { shortcode } = useParams();
    const [students, setStudents] = useState([]);
    const [cohorts, setCohorts] = useState([]);
    const [isLoaded, setIsLoaded] = useState(false);
  

  useEffect(() => {
    fetch(`http://127.0.0.1:8000/api/student/?cohort=${shortcode}`)
      .then((response) => response.json())
      .then(data => {
        setStudents(data);
        setIsLoaded(true);
      })
      .catch(error => console.log(error));

    fetch(`http://127.0.0.1:8000/api/cohort/${shortcode}/`)
    .then(response => response.json())
    .then(data => {
      setCohorts(data);
      setIsLoaded(true);
    })
    .catch(error => console.log(error));
  }, [shortcode]);

  const displayFacts = () => {
    return (
      <div>
        {students.map((student) => ( 
          <div key={student.student_id}> 
            <table style={{ borderCollapse: "collapse", width: "100%"}}>
            <thead>
            <tr>
              <th style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>Student Name</th>
              <th style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>Student Number</th>
            </tr>
            </thead>
            <tbody> 
                <tr>
                  <td style={{ border: "1px solid #ddd", padding: "8px" }}>
                  {student.first_name} {student.last_name}
                  </td>
                   <td style={{ border: "1px solid #ddd", padding: "8px" }}>
                   {student.student_id}
                   <br></br>
                   <Link to={`/student/${student.student_id}`}>View Student Information</Link>
                   </td>
                </tr>
            </tbody>
            </table>
            </div>
            ))}
      </div>
    );
  };




  if (isLoaded) {
    return (
    <div>
      <h1>{cohorts.name}</h1>
      <h2><strong>ID: </strong>{cohorts.id}</h2>
      <h2><strong>Year: </strong>{cohorts.year}</h2>
      <br></br>
      <h2>List of Students</h2>
      {displayFacts()}
      </div>
    )
  } 
  else {
    return <p>Loading Single Cohort Information...</p>;
  }
}

export default SingleCohort;
