import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import React from "react";
import { Link } from 'react-router-dom';
import { Card } from 'react-bootstrap';

function ModulesToCohort() {
  const {shortcode} = useParams();
  const [isLoaded, setIsLoaded] = useState(false);
  const [modules, setModules] = useState([]);

  useEffect(() => {
    fetch(`http://127.0.0.1:8000/api/module/?delivered_to=${shortcode}`)
      .then((response) => response.json())
      .then(data => {
        setModules(data);
        setIsLoaded(true);
      })
      .catch(error => console.log(error));
  });

  const displayFacts = () => {
    return (
      <div>
        <ul>
          {modules.map((module) => (
            <div key={module.code}>
              <p><strong>Module Name: </strong><Link to={`/module/${module.code}`}>{module.full_name}</Link></p>
              <p><strong>Module Code: </strong>{module.code}</p>
              <br></br>
            </div>
          ))}
        </ul>
      </div>
    );
  };



  if (isLoaded) {
    return (
      <div style={{marginRight: '80px', marginLeft: '80px'}}>
      <Card key={shortcode} className="cardstyle" style={{ paddingLeft: '20px', paddingRight: '20px', marginBottom: '1rem', backgroundColor: 'rgba(255, 255, 255, 0.5)' }}>
      <Card.Title><h2>Modules for {shortcode}</h2></Card.Title>
          <Card.Body>
            {displayFacts()}
          </Card.Body>
        </Card>
      </div>
    )
  } 
  else {
    return <p>Loading Module Information...</p>;
  }
}






export default ModulesToCohort;
