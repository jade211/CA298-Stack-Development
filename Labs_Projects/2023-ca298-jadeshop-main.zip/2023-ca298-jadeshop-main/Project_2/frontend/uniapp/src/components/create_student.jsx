import React from "react";
import { useState } from "react";
import { Card } from "react-bootstrap";


function CreateStudent() {
  const [student, setNewStudent] = useState({ first_name: "", last_name: "", student_id: "", email: "" });
  const [cohort, setCohort] = useState("")
  const [created, setCreated] = useState("");
  const [notcreated, setNotCreated] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
    if (student.student_id.length !== 8) {
        setNotCreated("Invalid Student Number Entered. Student Numbers must be 8 characters long.");
        setCreated("");
        return;
    }

    if (!student.email.endsWith("@dcu.ie")) {
        setNotCreated("Invalid Student Email Entered: Email must end with '@dcu.ie'");
        setCreated("");
        return;
    }

    const cohort_link = `http://127.0.0.1:8000/api/cohort/${cohort}/`;
    fetch("http://127.0.0.1:8000/api/student/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFTOKEN": "eNkOd2ZoPPn85OtLQnYILtaGidYgAgSzMWLudOwxvhtA24mJT7w792zqKDuQVo46",
      },
      body: JSON.stringify({ ...student, cohort: cohort_link}),
    })
      .then((response) => {
        return response.json();
      })
      .then((data) => {
        setCreated(`Student ${data.first_name} ${data.last_name} has been created!`);
        setNotCreated("");
        setNewStudent({first_name: "", last_name: "", student_id: "", email: ""});
        setCohort("");
        console.log(data);
      })
      .catch((error) => {
        setCreated("");
        setNotCreated(error.message);
        console.error(notcreated);
      });
  };

  const handleInputChange = (key, value) => {
    setNewStudent(prevModule => ({...prevModule, [key]: value }));
  };


  return (
    <div style={{marginRight: '80px', marginLeft: '80px'}}>
    <Card key={student.id} className="cardstyle" style={{ paddingLeft: '20px', paddingRight: '20px', marginBottom: '1rem', backgroundColor: 'rgba(255, 255, 255, 0.5)' }}>
      <br></br>
      <Card.Title><h2>Create New Student</h2></Card.Title>
      <Card.Body>
        <form onSubmit={handleSubmit}>
          <div>
            <h4>Student First Name:</h4>
            <input
              type="text"
              id="studentfirst_name"
              value={student.first_name}
              onChange={(e) => handleInputChange('first_name', e.target.value)}
              required/>
          </div>
          <div>
            <h4>Student Last Name:</h4>
            <input
              type="text"
              id="studentlast_name"
              value={student.last_name}
              onChange={(e) => handleInputChange('last_name', e.target.value)}
              required/>
          </div>
          <div>
            <h4>Student Number:</h4>
            <input
              type="text"
              id="student_id" 
              value={student.student_id} 
              onChange={(e) => handleInputChange('student_id', e.target.value)} 
              required/>
          </div>
          <div>
            <h4>Student Email</h4>
            <input
              type="text" 
              id="studentemail"
              value={student.email} 
              onChange={(e) => handleInputChange('email', e.target.value)}
              required />
          </div>
          <div>
            <h4>Cohort (UpperCase):</h4>
            <input
              type="text"
              id="cohort"
              value={cohort} 
              onChange={(e) => setCohort(e.target.value)}
              required />
          </div>

        <div>
        <button type="submit">Create Student</button>
        </div>
        {created}
        {notcreated}
      </form>
    </Card.Body>
    </Card>
  </div>
  );
}

export default CreateStudent;
