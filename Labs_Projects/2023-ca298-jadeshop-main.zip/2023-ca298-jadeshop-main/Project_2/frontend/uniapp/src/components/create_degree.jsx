import React, { useState } from "react";
import {Card} from 'react-bootstrap';

function CreateDegree() {
  const [degree, setNewDegree] = useState({ full_name: "", shortcode: "" });
  const [created, setCreated] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
    fetch("http://127.0.0.1:8000/api/degree/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFTOKEN":
          "eNkOd2ZoPPn85OtLQnYILtaGidYgAgSzMWLudOwxvhtA24mJT7w792zqKDuQVo46",
      },
      body: JSON.stringify(degree),
    })
      .then(response => {
        return response.json();
      })
      .then((data) => {
        setCreated(`${data.full_name} Degree has been created!`);
        setNewDegree({ full_name: "", shortcode: "" });
        console.log(data);
      })
      .catch((error) => {
        setCreated("");
        console.error(error);
      });
  };

  const handleInputChange = (event) => {
    const { id, value } = event.target;
    setNewDegree((prevState) => ({ ...prevState, [id]: value }));
  };

  return (
    <div style={{marginRight: '80px', marginLeft: '80px'}}>
      <Card key={degree.shortcode} className="cardstyle" style={{ paddingLeft: '20px', paddingRight: '20px', marginBottom: '1rem', backgroundColor: 'rgba(255, 255, 255, 0.5)' }}>
      <br></br>
      <Card.Title><h2>Create New Degree</h2></Card.Title>
      <Card.Body>
      <form onSubmit={handleSubmit}>
        <div>
          <h4>Degree Name:</h4>
          <input
            type="text"
            id="full_name"
            value={degree.full_name}
            onChange={handleInputChange}
            required
          />
        </div>
        <div>
          <h4>Shortcode:</h4>
          <input
            type="text"
            id="shortcode"
            value={degree.shortcode}
            onChange={handleInputChange}
            required
          />
        </div>
        <div>
          <button type="submit">Create Degree</button>
        </div>
        {created}
      </form>
      </Card.Body>
      </Card>
    </div>
  );
}

export default CreateDegree;
