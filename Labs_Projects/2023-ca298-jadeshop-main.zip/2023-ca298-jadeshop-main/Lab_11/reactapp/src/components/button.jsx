function MyButton(){
    return (
        <button onClick={
            ()=>{
                alert("Hi")
            }
        }>Click me </button>

    )
}

export default MyButton;
