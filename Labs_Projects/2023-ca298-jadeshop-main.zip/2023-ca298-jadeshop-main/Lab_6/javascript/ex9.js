function printMe () {
    console.log("Hello world");
}

printMe();
