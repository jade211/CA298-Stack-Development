let x = 7;
let y = 10;

let result = x * y;
console.log(result);
