let x = ['a','b','c','d','e']; 

for (val in x) {
    console.log(x[val]);
}
