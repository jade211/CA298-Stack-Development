let x = 10;
let y = 7;

function add (x, y) {
    console.log(x + y);
}

add(x, y);
