let x = 10;
let y = 7;

if(x > y) {
    console.log("X is greater than Y");
}
else {
    console.log("Y is greater than X");
}
