let person = {
      "Name": "John", "Age": "18", "Address": "123 street"
}

console.log(person.Name);
console.log(person.Age);
console.log(person.Address);
