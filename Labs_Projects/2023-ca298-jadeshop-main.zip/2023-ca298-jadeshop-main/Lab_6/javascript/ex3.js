let x = 0

console.log(x == []);
console.log(x == "0");
console.log("0" == []);
