let x = ['a','b','c','d','e']; 

for (val of x) {
    console.log(val);
}
