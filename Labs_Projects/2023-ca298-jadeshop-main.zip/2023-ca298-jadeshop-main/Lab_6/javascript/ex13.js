numlist = [];
let i = 0;

while(i <= 5) {
    numlist.push(i);
    i++;
}

for (val of numlist) {
    console.log(val);
}
