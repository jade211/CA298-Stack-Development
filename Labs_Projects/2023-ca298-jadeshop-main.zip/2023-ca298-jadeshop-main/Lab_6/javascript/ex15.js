let persons = [
    {"Name": "John", "Age": "18", "Address": "123 street"},
    {"Name":"Jane", "Age":"19", "Address":"124 street"},
    {"Name":"Sam", "Age":"20", "Address":"125 street"},
    {"Name":"Sarah", "Age":"21", "Address":"126 street"}
]


for (let i = 0; i < persons.length; i++) {
    console.log(persons[i].Name);
}
