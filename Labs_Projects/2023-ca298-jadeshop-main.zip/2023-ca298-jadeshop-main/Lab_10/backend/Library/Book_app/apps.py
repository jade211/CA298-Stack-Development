from django.apps import AppConfig


class BookAppConfig(AppConfig):
    name = 'Book_app'
