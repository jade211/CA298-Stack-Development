from django import forms
from django.forms import ModelForm, ModelChoiceField
from django.db import transaction
from .models import *

class NewClothes(forms.ModelForm):
    class Meta:
        model = Clothes
        fields = ['size', 'name', 'description', 'price', 'colour', 'stock', 'type']
