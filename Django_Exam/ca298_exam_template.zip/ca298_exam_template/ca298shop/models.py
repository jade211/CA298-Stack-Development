from django.db import models

# Create your models here.

class Size(models.Model):
    id = models.AutoField(primary_key = True)
    size = models.CharField(max_length = 30)

    def __str__(self):
        return '{}'.format(self.size)

class Type(models.Model):
    id = models.AutoField(primary_key = True)
    type = models.CharField(max_length = 30)

    def __str__(self):
        return '{}'.format(self.type)

class Clothes(models.Model):
    id = models.AutoField(primary_key = True)
    name = models.CharField(max_length = 30)
    description = models.TextField()
    price = models.DecimalField(decimal_places=2, max_digits=10)
    colour = models.CharField(max_length = 30)
    stock = models.IntegerField()

    # SIZE_CHOICES = [
    #     ('XS','Extra-Small'),
    #     ('S', 'Small'),
    #     ('M', 'Medium'),
    #     ('L', 'Large'),
    #     ('XL', 'Extra-Large')
    # ]
    # size = models.CharField(max_length=20, choices=SIZE_CHOICES, default='M')
    
    # TYPE_CHOICES = [
    #     ('tops','Tops'),
    #     ('bottoms', 'Bottoms'),
    #     ('shoes', 'Shoes'),
    #     ('coats', 'Coats'),
    # ]
    # type = models.CharField(max_length=20, choices=TYPE_CHOICES, default='tops')
    

    size = models.ForeignKey(Size, on_delete= models.CASCADE)
    type = models.ForeignKey(Type, on_delete= models.CASCADE)