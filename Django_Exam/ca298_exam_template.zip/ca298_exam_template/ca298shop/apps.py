from django.apps import AppConfig


class Ca298ShopConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "ca298shop"
