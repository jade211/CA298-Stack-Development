from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(Clothes)
admin.site.register(Size)
admin.site.register(Type)
