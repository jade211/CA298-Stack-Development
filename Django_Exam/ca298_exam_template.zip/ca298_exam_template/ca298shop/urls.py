from django.urls import path
from . import views
from . import forms


urlpatterns = [
    path('', views.index, name="homepage"),
    path('clothes', views.view_all_clothes, name='all_clothes'),
    path('clothes/<int:clothesid>', views.view_single_clothes, name='single_clothes'),

    path('create_clothes', views.create_clothes, name='create_clothes'),
    path('clothes/size/<str:size>', views.view_clothes_by_size, name='view_by_size'),
]