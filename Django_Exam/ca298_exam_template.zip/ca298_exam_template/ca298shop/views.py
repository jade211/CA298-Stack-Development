from django.shortcuts import render, get_object_or_404
from .models import *
from .forms import *


# Create your views here.
def index(request):
    return render(request,'index.html')

def view_all_clothes(request):
    all_clothes = Clothes.objects.all()
    return render(request, 'all_clothes.html', {'clothes': all_clothes})

def view_single_clothes(request, clothesid):
    single_clothes = get_object_or_404(Clothes, id=clothesid)
    clothes = Clothes.objects.get(id=clothesid)
    return render(request, 'single_clothes.html', {'clothes':single_clothes})


def view_clothes_by_size(request, size):
    # size = size.size
    by_size = Clothes.objects.filter(size=size)
    return render(request, 'all_clothes.html', {'clothes': by_size})


def create_clothes(request):
    if request.method == 'POST':
        form = NewClothes(request.POST)
        if form.is_valid():
            clothes = form.save()
            return render(request, 'created.html', {'clothes':clothes})
        else:
            return render(request, 'create_clothes.html', {'form':form})
    else:
        form = NewClothes()
        return render(request, 'create_clothes.html', {'form': form})
