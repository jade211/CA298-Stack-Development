import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { Button } from 'react-bootstrap';

function SingleStudent() {
  const {student_id} = useParams();
  const [student, setStudent] = useState([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [grades, setGrade] = useState([]);
  
  
  useEffect(() => {
    if(student_id) {
        fetch(`http://127.0.0.1:8000/api/student/${student_id}/`)
        .then((response) => response.json())
        .then(data => {
          setStudent(data);
          setIsLoaded(true);
        })
        .catch(error => console.log(error));
        fetch(`http://127.0.0.1:8000/api/grade/?student=${student_id}`)
        .then(response => response.json())
        .then(data => {
            setGrade(data.map((grade) => ({
                module: grade.module.split('/').slice(-2, -1)[0],
                //module: grade.module.endswith()
                grade: grade.total_grade.toFixed(),
                id: grade.id,
            })));
            setIsLoaded(true);
      })
      .catch(error => console.log(error)); 
    }
  }, [student_id]);


  const displayFacts = () => {
    return grades.map((grades) => {
        return (
            <div>
                <div key={grades.id}>
                    <table style={{ borderCollapse: "collapse", width: "100%" }}>
                        <thead>
                        <tr>
                            <th style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>Module</th>
                            <th style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>Grade Achieved</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td style={{ border: "1px solid #ddd", padding: "8px" }}>
                            <Link to={`../module/${grades.module}`}>{grades.module}</Link>
                            </td>
                            <td style={{ border: "1px solid #ddd", padding: "8px" }}>
                            {grades.grade}% 
                            </td>
                            <td>
                            <Button variant="success" as={Link} to={`/setgrade/${grades.id}`}>Set Grade Manually</Button>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    <br></br>
                    </div>
      </div>
    );
  })};


  if (isLoaded) {
    return (
    <div>
      <h2>Information on Student: {student_id}</h2>
      <div key={student.id}>
                <strong>Name: </strong>{student.first_name} {student.last_name}<br></br>
                <strong>Email: </strong> {student.email}<br></br>
                <strong>Student Number: </strong> {student.student_id}
        </div>
      {displayFacts()}
      </div>
    )
  } 
  else {
    return <p>Loading Student Information...</p>;
  }
}

export default SingleStudent;
