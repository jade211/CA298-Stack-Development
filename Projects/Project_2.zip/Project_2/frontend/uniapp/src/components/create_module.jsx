import React from "react";
import { useState } from "react";
import { Card } from "react-bootstrap";


function CreateModule() {
  const [module, setNewModule] = useState({ full_name: "", code: "", ca_split: 0});
  const [delivered_to, setDelivered_to] = useState("")
  const [created, setCreated] = useState("");
  const [notcreated, setNotCreated] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
  
    if (module.ca_split < 0 || module.ca_split > 100) {
      setNotCreated("CA Percentage Invalid: Must be a number between 0 and 100.");
      setCreated("");
      return;
    }

    const delivered_to_link = `http://127.0.0.1:8000/api/cohort/${delivered_to}/`;
    fetch("http://127.0.0.1:8000/api/module/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFTOKEN": "eNkOd2ZoPPn85OtLQnYILtaGidYgAgSzMWLudOwxvhtA24mJT7w792zqKDuQVo46",
      },
      body: JSON.stringify({ ...module, delivered_to: [delivered_to_link]}),
    })
      .then((response) => {
        return response.json();
      })
      .then((data) => {
        setCreated(`Module ${data.code} has been created!`);
        setNotCreated("");
        setNewModule({full_name: "", code: "", ca_split: 0});
        setDelivered_to("");
        console.log(data);
      })
      .catch((error) => {
        setCreated("");
        setNotCreated(error.message);
        console.error(notcreated);
      });
  };

  const handleInputChange = (key, value) => {
    setNewModule(prevModule => ({...prevModule, [key]: value }));
  };


  return (
    <div style={{marginRight: '80px', marginLeft: '80px'}}>
    <Card key={module.code} className="cardstyle" style={{ paddingLeft: '20px', paddingRight: '20px', marginBottom: '1rem', backgroundColor: 'rgba(255, 255, 255, 0.5)' }}>
      <br></br>
      <Card.Title><h2>Create New Module</h2></Card.Title>
      <Card.Body>
      <div>
        <form onSubmit={handleSubmit}>
          <div>
            <h4>Module Name:</h4>
            <input
              type="text"
              id="module.full_name"
              value={module.full_name}
              onChange={(e) => handleInputChange('full_name', e.target.value)}
              required/>
          </div>
          <div>
            <h4>Module Code:</h4>
            <input
              type="text"
              id="module.code" 
              value={module.code} 
              onChange={(e) => handleInputChange('code', e.target.value)} 
              required/>
          </div>
          <div>
            <h4>CA Split:</h4>
            <input
              type="text" 
              id="module.ca_split"
              value={module.ca_split} 
              onChange={(e) => handleInputChange('ca_split', e.target.value)}
              required />
          </div>
          <div>
            <h4>Cohort (UpperCase):</h4>
            <input
              type="text"
              id="delivered_to"
              value={delivered_to} 
              onChange={(e) => setDelivered_to(e.target.value)}
              required />
          </div>

        <div>
        <button type="submit">Create Module</button>
        </div>
        {created}
        {notcreated}
      </form>
    </div>
    </Card.Body>
    </Card>
  </div>
  );
}

export default CreateModule;
