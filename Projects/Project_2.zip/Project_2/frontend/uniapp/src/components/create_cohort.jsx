import React, { useState } from "react";
import { Card } from 'react-bootstrap';

function CreateCohort() {
  const [cohort, setNewCohort] = useState({ degree: "", id: "", year: 1 });
  const [created, setCreated] = useState("");

  const ExistingDeg = (id) => {
    if(`http://127.0.0.1:8000/api/degree/${id}/`) {
      return `http://127.0.0.1:8000/api/degree/${id}/`;
    }
  }

  const handleInputChange = (event) => {
    const { id, value } = event.target;
    setNewCohort((prevState) => ({ ...prevState, [id]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if(ExistingDeg(cohort.id))
      cohort.degree = ExistingDeg(cohort.id);
      cohort.id = cohort.id + cohort.year;
    fetch("http://127.0.0.1:8000/api/cohort/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFTOKEN": "eNkOd2ZoPPn85OtLQnYILtaGidYgAgSzMWLudOwxvhtA24mJT7w792zqKDuQVo46",
      },
      body: JSON.stringify(cohort),
    })
      .then((response) => {
        return response.json();
      })
      .then((data) => {
        setCreated(`${data.id} cohort has been created!`);
        setNewCohort({ degree: "", id: "", year: 1 });
        console.log(data);
      })
      .catch((error) => {
        setCreated("");
        console.error(error);
      });
  };
  
  return (
    <div style={{marginRight: '80px', marginLeft: '80px'}}>
      <Card key={cohort.id} className="cardstyle" style={{ paddingLeft: '20px', paddingRight: '20px', marginBottom: '1rem', backgroundColor: 'rgba(255, 255, 255, 0.5)' }}>
      <br></br>
      <Card.Title><h2>Create New Cohort</h2></Card.Title>
      <Card.Body>
      <form onSubmit={handleSubmit}>
      <div>
          <h4>Degree:</h4>
          <input
            type="text"
            id="degree"
            value={cohort.degree}
            onChange={handleInputChange} required/>
        </div>
        <div>
          <h4>Year:</h4>
          <input
            type="number"
            id="year" 
            value={cohort.year} 
            onChange={handleInputChange} required/>
        </div>
        <div>
          <h4>Existing Degree Shortcode:</h4>
          <input
            type="text" 
            id="id"
            value={cohort.id} 
            onChange={handleInputChange} required/>
        </div>
        <div>
          <button type="submit">Create Cohort</button>
        </div>
        {created}
      </form>
      </Card.Body>
      </Card>
    </div>
  );
}

export default CreateCohort;
