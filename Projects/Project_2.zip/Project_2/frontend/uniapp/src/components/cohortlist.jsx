import { useState, useEffect } from "react";
import { Link } from 'react-router-dom';
import React from 'react';
import {Card, Button } from 'react-bootstrap';

function CohortList(){
    const [cohort, setcohort] = useState([]);
    const [isLoaded, setIsLoaded] = useState(false);

    useEffect(() => {
        fetch(`http://127.0.0.1:8000/api/cohort/`)
        .then(response => response.json())
        .then(data => {
            setcohort(data.map(element => element));
            setIsLoaded(true);
        })
        .catch(error => console.log(error));
    }, []);

    const displayFacts = () => {
        return cohort.map(elem=>
            <Card key={elem.id} className="cardstyle" style={{marginBottom: '1rem', backgroundColor: 'rgba(255, 255, 255, 0.5)'}}>
                <Card.Body>
                    <Card.Title><strong>Title: </strong>{elem.name}</Card.Title>
                        <Card.Text>
                        <Button variant="dark" as={Link} to={`/cohort/${elem.id}`}>View Cohort Information</Button>
                        <br></br>
                        <br></br>
                        <Button variant="dark" as={Link} to={`/cohort/modules/${elem.id}`}>View Cohort Modules</Button>
                        </Card.Text>
                </Card.Body>
            </Card>
        )
    };

    if(isLoaded){
        return (
            <ul>
                <h2>Cohort Information</h2>
                {displayFacts()}
                <button type="submit"><Link to="/createcohort">Create Cohort</Link></button>
            </ul>
        )
    }
    else{
        return (
            <p>Loading Cohort Information...</p>
        )
    }
}

export default CohortList;
