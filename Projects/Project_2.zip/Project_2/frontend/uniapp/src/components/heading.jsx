import degreesimage from '../degree.jpeg';
import cohortsimage from '../cohorts.jfif';
import modulesimage from '../modules.png';

function HeadingComponent(){
	return (
		<div>
			<h1>University Homepage!</h1>
			<div className="image-homepage">
			<a href="/degree"><img src={degreesimage} alt="degrees" className="image1"/></a>
				<div className="image-text">
				<a href="/degree"><h2>All Degrees</h2></a>
					<p> This page displays all of the degrees 
						on offer in the University as well as 
						the specific details regarding each degree.</p>
				</div>
			<a href="/degree"><img src={degreesimage} alt="degrees" className="image2"/></a>
			</div>

			<br></br>


			<div className="image-homepage">
			<a href="/cohort"><img src={cohortsimage} alt="cohorts" className="image1"/></a>
				<div className="image-text">
				<a href="/cohort"><h2>All Cohorts</h2></a>
					<p> This page displays all of the different cohorts per degree 
						along with their information. It also displays the students enrolled
						in that particular cohort.</p>
				</div>
			<a href="/cohort"><img src={cohortsimage} alt="cohorts" className="image2"/></a>
			</div>

			<br></br>

			<div className="image-homepage">
			<a href="/module"><img src={modulesimage} alt="modules" className="image1"/></a>
			<div className="image-text">
			<a href="/module"><h2>All Modules</h2></a>
				<p> This page displayes all of the different modules the university has to 
					offer as well as the information on those modules.</p>
				</div>				
			<a href="/module"><img src={modulesimage} alt="modules" className="image2"/></a>
			</div>


		</div> 
	);
}

export default HeadingComponent;