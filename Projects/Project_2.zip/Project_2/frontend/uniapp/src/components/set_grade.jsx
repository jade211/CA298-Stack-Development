import React, { useState} from 'react';
import { useParams } from "react-router-dom";

function ChangeModuleGrade() {
  const { id } = useParams();
  const [newgrade, setNewgrade] = useState({ca_mark: '', exam_mark: ''});
  const [created, setCreated] = useState("");

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setNewgrade({ ...newgrade, [name]: value });
  };

  const handleSubmit = (event) => {
    event.preventDefault(); // Prevent default form submission
    fetch(`http://127.0.0.1:8000/api/grade/${id}/`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ca_mark: newgrade.ca_mark, exam_mark: newgrade.exam_mark, 
        total_mark: parseFloat(newgrade.ca_mark) + parseFloat(newgrade.exam_mark) 
      })})
      .then((response) => {
        return response.json();
      })
      .then((data) => {
        setCreated(`Grade has been changed successfully!`);
        console.log(data);
      })
      .catch((error) => {
        setCreated("");
        console.error(error);
      });
  };

  return (
    <div>
      <h2>Change Module Grade</h2>
      <div>
        <div>
          <form onSubmit={handleSubmit}>
            <div>
              <label>Continuous Assessment Mark (% achieved out of 100):</label>
              <input
                type="number"
                name="ca_mark"
                value={newgrade.ca_mark}
                onChange={handleInputChange}
                max={100}
              />
            </div>
            <div>
              <label>Final Exam Mark (% achieved out of 100)</label>
              <input
                type="number"
                name="exam_mark"
                value={newgrade.exam_mark}
                onChange={handleInputChange}
                max={100}
              />
            </div>
            <div><button type="submit">Update</button>
            </div>
            {created !== "" && <p>{created}</p>}
          </form>
        </div>
      </div>
    </div>
  );
};

export default ChangeModuleGrade;
