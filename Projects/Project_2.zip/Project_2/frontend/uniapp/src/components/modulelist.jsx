import { useState, useEffect } from "react";
import { Link } from 'react-router-dom';
import React from 'react';
import {Card, Button } from 'react-bootstrap';

function ModuleList(){
    const [module, setmodule] = useState([]);
    const [isLoaded, setIsLoaded] = useState(false);


    useEffect(() => {
        fetch(`http://127.0.0.1:8000/api/module/`)
        .then(response => response.json())
        .then(data => {
            setmodule(data.map(element => element));
            setIsLoaded(true);
        })
        .catch(error => console.log(error));
    });

    
    const displayFacts = () => {
        return module.map(elem=>
            <Card key={elem.id} className="cardstyle" style={{marginBottom: '1rem', backgroundColor: 'rgba(255, 255, 255, 0.5)'}}>
                <Card.Body>
                    <Card.Title><strong>Code: </strong>{elem.code}</Card.Title>
                    <Card.Text>
                        <strong>Module: </strong>{elem.full_name}<br></br>
                        <Button variant="dark" as={Link} to={`/module/${elem.code}`}>View Module Information</Button>
                    </Card.Text>
                </Card.Body>
            </Card>
        )
    };

    if(isLoaded){
        return (
            <ul>
                <h2>Module Information</h2>
                {displayFacts()}
                <button type="submit"><Link to={`/createmodule/`}>Create New Module</Link></button>
            </ul>
        )
    }
    else{
        return (
            <p>Loading Module Information...</p>
        )
    }
}

export default ModuleList;
