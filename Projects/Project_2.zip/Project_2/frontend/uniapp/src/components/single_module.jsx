import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import React from "react";
import { Link } from "react-router-dom";
import { Card } from 'react-bootstrap';

function SingleModule() {
  const {code} = useParams();
  const [isLoaded, setIsLoaded] = useState(false);
  const [module, setModule] = useState([]);
  

  useEffect(() => {
    fetch(`http://127.0.0.1:8000/api/module/${code}`)
    .then(response => response.json())
    .then(data => {
      setModule(data);
      setIsLoaded(true);
    })
    }, [code]);

  const displayFacts = () => {
    const cohorts = module.delivered_to.map((cohort) => {
      const cohortArray = cohort.trim().split('/');
      
      return (
        <span key={cohort}>
          <Link to={`/cohort/${cohortArray[cohortArray.length - 2]}`}>{cohortArray[cohortArray.length - 2]}</Link>
          {', '}
        </span>
      );
    });
    
    return (
      <div>
        <div key={module.id}>    
          <h2>{module.full_name}</h2>
          <p><strong>Module ShortCode: </strong>{module.code}</p>
          <p><strong>Delivered to: </strong>{cohorts} <br /></p>
          <p><strong>CA Marks: </strong>{module.ca_split}%</p>
        </div>
      </div>
    );
  };


  if (isLoaded) {
    return (
      <div style={{marginRight: '80px', marginLeft: '80px'}}>
      <Card key={code} className="cardstyle" style={{ paddingLeft: '20px', paddingRight: '20px', marginBottom: '1rem', backgroundColor: 'rgba(255, 255, 255, 0.5)' }}>
        <Card.Body>
        {displayFacts()}
        </Card.Body>
      </Card>
      </div>
    )
  } 
  else {
    return <p>Loading Single Module Information...</p>;
  }
}

export default SingleModule;
