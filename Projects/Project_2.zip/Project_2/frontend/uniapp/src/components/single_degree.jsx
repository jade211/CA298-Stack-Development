import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { Card } from 'react-bootstrap';

function SingleDegree() {
  const {shortcode} = useParams();
  const [cohorts, setCohorts] = useState([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [degree, setDegree] = useState([]);
  

  useEffect(() => {
    fetch(`http://127.0.0.1:8000/api/cohort/?degree=${shortcode}`)
      .then((response) => response.json())
      .then(data => {
        setCohorts(data);
        setIsLoaded(true);
      })
      .catch(error => console.log(error));
    fetch(`http://127.0.0.1:8000/api/degree/${shortcode}`)
    .then(response => response.json())
    .then(data => {
      setDegree(data);
      setIsLoaded(true);
    })
    .catch(error => console.log(error));
  }, [shortcode]);

  const displayFacts = () => {
    return (
      <div>    
          {cohorts.map(cohort => (
            <div key={cohort.id}>
              <strong>Name: </strong>{cohort.name}<br></br>
              <strong>Shortcode: </strong> {cohort.id}
            </div>
          ))}
      </div>
    );
  };

  if (isLoaded) {
    return (
      <div style={{marginRight: '80px', marginLeft: '80px'}}>
      <Card key={degree.shortcode} className="cardstyle" style={{ paddingLeft: '20px', paddingRight: '20px', marginBottom: '1rem', backgroundColor: 'rgba(255, 255, 255, 0.5)' }}>
      <Card.Title><h1>{degree.full_name} ({degree.shortcode})</h1></Card.Title>
        <h2>List of Cohorts for {shortcode}</h2>
        <Card.Body>
          {displayFacts()}
        </Card.Body>
      </Card>
      </div>
    )
  } 
  else {
    return <p>Loading Single Degree Information...</p>;
  }
}

export default SingleDegree;
