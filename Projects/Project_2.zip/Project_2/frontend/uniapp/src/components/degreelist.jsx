import { useState, useEffect } from "react";
import { Link } from 'react-router-dom';
import React from 'react';
import {Card, Button } from 'react-bootstrap';

function DegreeList(){
  const [degrees, setDegrees] = useState([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    fetch(`http://127.0.0.1:8000/api/degree/`)
      .then(response => response.json())
      .then(data => {
        setDegrees(data);
        setIsLoaded(true);
      })
      .catch(error => console.log(error));
  });

  const displayFacts = () => {
    return degrees.map(degree =>
      <Card key={degree.id} className="cardstyle" style={{marginBottom: '1rem', backgroundColor: 'rgba(255, 255, 255, 0.5)'}}>
          <Card.Body>
            <Card.Title><strong>Degree Title: </strong>{degree.full_name}</Card.Title>
            <Card.Text>
              <strong>Degree Short Code: </strong>{degree.shortcode}
            <br></br>
            <Button variant="dark" as={Link} to={`/degree/${degree.shortcode}`}>View Degree Information</Button>
            </Card.Text>
          </Card.Body>
      </Card>
    )
  };

  if(isLoaded) {
    return (
      <div className="degreelist">
        <h2>Degrees Available</h2>
        {displayFacts()}
        <button type="submit"><Link to={`/createdegree/`}>Create New Degree</Link></button>
      </div>
    )
  }
  else {
    return (
      <p>Loading Degree Information...</p>
    )
  }
}

export default DegreeList;
