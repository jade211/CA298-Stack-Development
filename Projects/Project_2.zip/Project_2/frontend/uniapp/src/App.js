import './App.css';
import "./styles.css";
import HeadingComponent from './components/heading';
import DegreeList from './components/degreelist';
import CohortList from './components/cohortlist';
import ModuleList from './components/modulelist';
import SingleDegree from './components/single_degree';
import SingleModule from './components/single_module';
import SingleCohort from './components/single_cohort';
import ModulesToCohort from './components/modules_delivered';

import CreateDegree from './components/create_degree';
import CreateCohort from './components/create_cohort';
import CreateModule from './components/create_module';
import CreateStudent from './components/create_student';

import SingleStudent from './components/single_student';

import ChangeModuleGrade from './components/set_grade';


import { BrowserRouter, Routes, Route} from 'react-router-dom';
import React from 'react';
import { Nav, Navbar, NavDropdown } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
          <Navbar bg="light" expand="lg" className="Navbar-nav">
            <Navbar.Brand href="/" className="site-title">University Homepage</Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
              <Nav className="mr-auto">
              <Nav.Link href="/degree">Degrees Available</Nav.Link>
              <Nav.Link href="/cohort">All Cohorts</Nav.Link>
              <Nav.Link href="/module">Modules Available</Nav.Link>
              <NavDropdown title="Editing Section" id="basic-nav-dropdown">
              <NavDropdown.Item href="/createdegree">Add Degree</NavDropdown.Item>
              <NavDropdown.Item href="/createcohort">Add Cohort</NavDropdown.Item>
              <NavDropdown.Item href="/createmodule">Add Module</NavDropdown.Item>
              <NavDropdown.Item href="/createstudent">Add Student</NavDropdown.Item>
            </NavDropdown>
          </Nav>
        </Navbar.Collapse>
      </Navbar>

      <Routes>
          <Route exact path="/" element={<HeadingComponent />} />
          <Route exact path="/degree" element={<DegreeList />} />
          <Route exact path="/cohort" element={<CohortList />} />
          <Route exact path="/module" element={<ModuleList />} />
          <Route exact path="/degree/:shortcode" element={<SingleDegree />} />
          <Route exact path="/module/:code" element={<SingleModule />} />
          <Route exact path="/cohort/:shortcode" element={<SingleCohort />} />
          <Route exact path="/cohort/modules/:shortcode" element={<ModulesToCohort />} />
          
          <Route exact path="/createdegree" element={<CreateDegree />} />
          <Route exact path="/createcohort" element={<CreateCohort/>} />
          <Route exact path="/createmodule" element={<CreateModule/>} />
          <Route exact path="/createstudent" element={<CreateStudent/>} />
        

          <Route exact path="/student/:student_id" element={<SingleStudent />} />

          <Route exact path="/setgrade/:id" element={<ChangeModuleGrade/>} />
          
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
