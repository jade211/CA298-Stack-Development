from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse
from .models import *
from .forms import *


# Create your views here.

# Index/Pizza creation
def createPizza(request):
    if request.method == 'POST':
        form = NewPizza(request.POST)
        if form.is_valid():
            pizza = form.save()
            return redirect('createCustomer', pizzaId = pizza.id)
        else:
            return render(request, 'index.html', {'form':form})
    else:
        form = NewPizza()
        return render(request, 'index.html', {'form': form})


def createCustomer(request, pizzaId=0):
    if request.method == 'POST':
        form = NewCustomer(request.POST)
        pizza = request.POST['pizza']
        if form.is_valid():
            createCustomer = form.save()
            createCustomer.pizza = get_object_or_404(CreatePizza , id=pizza)
            return redirect('customer_pizza', customerId = createCustomer.id)
        else:
            return render(request, 'customer.html', {'form': form, 'pizzaId': pizza})
    else:
        form = NewCustomer()
        return render(request, 'customer.html', {'form': form, 'pizzaId': pizzaId})



def customer_pizza(request, customerId):
    customer = get_object_or_404(Customer, id=customerId)
    return render(request, 'created.html', {'customer':customer})


def contact(request):
    return render(request, 'contact.html')
