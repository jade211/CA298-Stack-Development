from django.db import models

# Create your models here.


# Size, Crust, Sauce, Cheese - To be used in CreatePizza
class Size(models.Model):
    id = models.AutoField(primary_key = True)
    size = models.CharField(max_length = 30)

    def __str__(self):
        return '{}'.format(self.size)


class Crust(models.Model):
    id = models.AutoField(primary_key = True)
    crust = models.CharField(max_length = 30)

    def __str__(self):
        return '{}'.format(self.crust)


class Sauce(models.Model):
    id = models.AutoField(primary_key = True)
    sauce = models.CharField(max_length = 30)

    def __str__(self):
        return '{}'.format(self.sauce)
    

class Cheese(models.Model):
    id = models.AutoField(primary_key = True)
    cheese = models.CharField(max_length = 300)

    def __str__(self):
        return '{}'.format(self.cheese)


# Main models
class CreatePizza(models.Model):
    id = models.AutoField(primary_key = True)
    size = models.ForeignKey(Size, on_delete= models.CASCADE)
    crust = models.ForeignKey(Crust, on_delete= models.CASCADE)
    sauce = models.ForeignKey(Sauce, on_delete= models.CASCADE)
    cheese = models.ForeignKey(Cheese, on_delete= models.CASCADE)
    
    pepperoni = models.BooleanField()
    chicken = models.BooleanField()
    ham = models.BooleanField()
    pineapple = models.BooleanField()
    mushrooms = models.BooleanField()
    peppers = models.BooleanField()
    onions = models.BooleanField()
    olives = models.BooleanField()
    extra_cheese = models.BooleanField()
    bacon = models.BooleanField()
    sundried_tomatoes = models.BooleanField()
    sweetcorn = models.BooleanField()
    jalapeno_peppers = models.BooleanField()
    sausage = models.BooleanField()
    pickles = models.BooleanField()


class Customer(models.Model):
    id = models.AutoField(primary_key = True)
    name = models.CharField(max_length = 100)
    address = models.CharField(max_length = 100)
    card_number = models.CharField(max_length = 100)
    card_expiry_month = models.IntegerField()
    card_expiry_year = models.IntegerField()
    card_cvv = models.IntegerField()
    pizza = models.ForeignKey("CreatePizza", on_delete=models.CASCADE)

    def __str__(self):
        return 'Name: {} Address: {}'.format(self.name, self.address)

